namespace Blueprints.StateController.Core
{
    public enum StateTaskSwitch
    {
        None,
        Enter,
        Idle,
        Exit,
    }
}